﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EnumFilesGroup_1
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                MainMenu mainMenu = new MainMenu();
            }
            while (true);

            
            
        }

       public enum LastNames
        { 
            Erna,
            Paaño,
            Ito,
            Baliwag,
            Norella
        };

        public class MainMenu
        {
            string m;
            public  MainMenu ()
            {
           
                Console.WriteLine("Welcome To Working with Files\n");
                Console.WriteLine("[1] Record File");
                Console.WriteLine("[2] Retrieved File");
                Console.WriteLine("[3] Exit");
                Console.Write("Select from the Menu: ");
                m = Console.ReadLine();
                
                switch(m)
                {
                    case "1":
                        RecordFiles RecordFiles = new RecordFiles();
                        break;
                    case "2":
                        RetrieveFiles RetrieveFiles = new RetrieveFiles();
                        break;
                    case "3":
                        Console.WriteLine("Thank you for using! \n");
                        break;
                        
                }
            }
        }


        public class RecordFiles
        {
            string filePath;

            public RecordFiles()
            {
                Console.Write("Enter the file name: ");
                filePath = Console.ReadLine();
              
                var p = LastNames.Paaño;
                var e = LastNames.Erna;
                var i = LastNames.Ito;
                var b = LastNames.Baliwag;
                var n = LastNames.Norella;

                try
                {
                    if (File.Exists(filePath))
                    {
                        Console.WriteLine("The "+ filePath +" is existing. \n");
                      
                    }
                    else 
                    
                    
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine("File "+ filePath +" not found and will be created.");
                        Console.WriteLine("The names are already recorded in the "+ filePath);
                        {

                                
                                string[] lines = { p.ToString(), e.ToString(), i.ToString(), b.ToString(),n.ToString() };
                                System.IO.File.AppendAllLines(filePath, lines);
                        }

                    }
                }
                catch(Exception Ex)
                {
                    Console.WriteLine(Ex.ToString());
                }
            }
        }
    }

         public  class RetrieveFiles
        {
        string fname;
        public RetrieveFiles()
        {
            Console.Write("Enter the file name: ");
            fname = Console.ReadLine();

            if (File.Exists(fname))
            {
                Console.WriteLine("File " + fname + " found and below are the content of this file\n");
                using (StreamReader sr = File.OpenText(fname))
                {
                    string s = "";
                    while ((s = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(s);
                        
                    }
                    Console.WriteLine("\nss");
                }
            }
            else
            {
                Console.WriteLine("The file was not found. \n");
            }
        }
        }
    }
    
